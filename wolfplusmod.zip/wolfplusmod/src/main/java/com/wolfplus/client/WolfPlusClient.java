package com.wolfplus.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;

public class WolfPlusClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {

        System.out.println("🐺 WolfPlus Client chargé !");

        // Tick client (base future UI)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (MinecraftClient.getInstance().player != null) {
                // futur système UI / overlay
            }
        });

        // 🐺 CLIC DROIT SUR LOUP
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {

            if (!world.isClient()) return ActionResult.PASS;

            if (entity instanceof WolfEntity wolf) {

                if (wolf.isTamed()) {

                    player.sendMessage(
                        Text.literal("🐺 Loup apprivoisé détecté ! UI prêt"),
                        false
                    );

                    System.out.println("🐺 Wolf clicked (tamed)");

                    // 👉 FUTUR : ouverture UI ici
                }
            }

            return ActionResult.PASS;
        });
    }
}