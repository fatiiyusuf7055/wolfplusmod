package com.wolfplus;

import net.fabricmc.api.ModInitializer;

public class WolfPlusMod implements ModInitializer {

    @Override
    public void onInitialize() {
        System.out.println("🐺 WolfPlus Mod chargé !");
    }
}